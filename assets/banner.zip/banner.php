<html>

<!-- Cabeçalho da página -->
<head style="height: 100%;">
<title>Banner</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<!-- Requisição de arquivos externos -->
<link rel="stylesheet" href="css/estilo.css" type="text/css"/>
<link rel="stylesheet" href="css/carrossel.css" type="text/css"/>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jcarousel.js"></script>

<!-- Controle de movimento do carrossel -->
<script language="javascript" type="text/javascript">
$(function(){
   $(".carrossel").jCarouselLite({
     btnNext: ".next",
     btnPrev: ".prev",
     visible: 1,
     auto: 5000,
     speed: 2000
     })
})   
</script> 

</head>

<!-- Estilos da página -->
<style>
   
    table.rounded-corners {
	border-radius: 10px;
        }      
    table.rounded-corners tr:first-child td:first-child {
	border-top-left-radius: 20px;
        border:1px solid silver;
	bgcolor: white;
	padding:0px 2px 3px;
        }
    table.rounded-corners tr:first-child td:last-child {
	border-top-right-radius: 20px;
        border:1px solid silver;
	bgcolor: white;
	padding:0px 2px 3px;
	}
    table.rounded-corners tr:last-child td:first-child {
	border-bottom-left-radius: 20px;
        border:1px solid silver;
	bgcolor: white;
	padding:0px 2px 3px;
        }
    table.rounded-corners tr:last-child td:last-child {
	border-bottom-right-radius: 20px;
        border:1px solid silver;
	bgcolor: white;
	padding:0px 2px 3px;
    }
    
    .bordaBox {background:black; width:90%;}
    .bordaBox .b1, .bordaBox .b2, .bordaBox .b3, .bordaBox .b4, .bordaBox .b1b, .bordaBox .b2b, .bordaBox .b3b, .bordaBox .b4b {display:block; overflow:hidden; font-size:3px;}
    .bordaBox .b1, .bordaBox .b2, .bordaBox .b3, .bordaBox .b1b, .bordaBox .b2b, .bordaBox .b3b {height:1px;}
    .bordaBox .b2, .bordaBox .b3, .bordaBox .b4 {background:black; border-left:1px solid black; border-right:1px solid black;}
    .bordaBox .b1 {margin:0 5px; background:black;}
    .bordaBox .b2 {margin:0 3px; border-width:0 2px;}
    .bordaBox .b3 {margin:0 2px;}
    .bordaBox .b4 {height:2px; margin:0 1px;}
    .bordaBox .conteudo {text-align:center; font-family:Arial, Helvetica, sans-serif; color:white; padding:0px;display:block; background:black; border-left:1px solid black; border-right:1px solid black;}

</style>
    
<!-- Corpo da página -->
<body style="height: 100%;" onload="loadpage();" link=black vlink=black alink=black>      

<!-- Tabela de fundo -->    
<table class="rounded-corners" height="50%" width="100%" cellspacing="10">
     <tr height="270">
        <td style="vertical-align: top;" align="center" bgcolor="#f4f4f4" width="50%">

           <!-- Título do banner --> 
           <div style="width:400px; height:18px; position:relative; top:0px; left:0px; border:0px solid #c3c3c3; background-color:#369369; padding:0px 10px; z-index:1;">
              <font face="Arial, Helvetica, sans-serif" color="white" size="2">
                <marquee>Insira aqui as imagens para chamadas publicitárias</marquee>
              </font>
           </div><br>

           <!-- Banner em carrocel--> 
           <div id="carrossel">
              <button class="prev"></button>
              <button class="next"></button> 
              <div class="carrossel">

               <!-- Inicia a lista buscando fotos no diretório --> 
               <ul>
                <?php
                // Define o diretório das fotos
                $vDir = "./fotos"; 
                // Manipula o diretório
                $vHandle = opendir($vDir); 
                // Carrega todos os arquivos até chegar no último
                while (false !== ($vArquivo = readdir($vHandle))) 
                 { 
                  // Verifica se o arquivo é PNG
                  if (substr($vArquivo,-4) == ".png") 
                    { 
                     // Insere a imagem na lista para exibição
                     echo('<li><img src="'.$vDir.'/'.$vArquivo.'" alt="" /></li>'); 
                    }
                  }
                ?>
               </ul><br>
             </div>
          </div>
      </td>
     </tr>
</table>  
        
</body>
</html>
